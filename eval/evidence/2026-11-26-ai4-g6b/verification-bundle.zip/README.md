# ChargePilot SC-16 · G6B final remediation

**READY_FOR_FINAL_ACCEPTANCE**

**STOP — WAITING_FOR_TECH_LEAD_FINAL_ACCEPTANCE.**

Codex integrated the Tech Lead's B1/B2 patch on the primary repository's
`feature/ai-4-how-to` branch at `64c85f1624ee2893eff776a1e82fbdd893d3fe4d`.
The reviewed Carbon V3 mirror commit was
`92f091343770c24ba017c343c5a326c86bc622bb`. The V3 private export matched its
own provenance manifest on 51/51 candidate files and 40/40 executed files.
Direct comparison with the mirror matched 50/51 blobs. The remaining blob
was the primary repository's `.gitignore`, preserved from its V3 worktree.

- `regression.tsv` records the three failures on V3 and passes after the fix.
- `verification.tsv` records exit codes from the final clean export.
  The targeted, focused, legacy, regression and architecture counts are subsets
  of the full backend count.
- `scope.tsv` and `candidate-files.tsv` record the scope and file provenance.
- `v3-mirror-parity.tsv` records the V3 Git blob comparison.
- `historical-sha256.tsv` identifies the original Codex and Carbon V1–V3 artifacts
  retained in the local archive.
- `SHA256SUMS` covers the patch and `CONTENTS.sha256` covers the other bundle entries.

## Reproduce

In the primary repository, export the original baseline and apply the patch
from this ZIP. The baseline already contains the genuine `.env.example`.

```bash
export_dir=$(mktemp -d)
git archive 64c85f1624ee2893eff776a1e82fbdd893d3fe4d | tar -x -C "$export_dir"
git -C "$export_dir" apply --check --whitespace=error-all /path/to/candidate.patch
git -C "$export_dir" apply /path/to/candidate.patch
```

Use the project's Python dependencies, including EV2Gym 2.0.0, and install
the frontend dependencies using the unchanged `frontend/package-lock.json`.
This run used Python 3.12.3, Starlette 1.10.0, AnyIO 4.16.0, pytest 9.2.0,
Ruff 0.17.5, Node 22.23.5, Next.js 16.4.6 and Playwright 1.65.1 with Chromium
159.0.8154.6. The clean export used SQLite fixtures, a scripted model, real
HTTP, and the real advisory engines. Live LLM, PostgreSQL runtime and load
validation are pending G7.

Install Playwright into `toolkit/` under a separate tools directory and
install Chromium with `PLAYWRIGHT_BROWSERS_PATH` set to the tools directory's
`browser/` subdirectory. On Linux, supply the host browser libraries.
Run with loopback binding available and with ports 38190 and 33190 free.

```bash
bash /path/to/run-clean.sh /path/to/browser-tools "$export_dir" /path/to/local-logs
```

To reproduce fail-before, export the same baseline with the retained Carbon
V3 patch and apply only the new regression file from the Tech Lead patch.
Run `pytest -q tests/test_api/test_g6b_v3_bounds_and_disconnect.py` on each
tree. The targeted patch SHA-256 is
`3fbf0bdb01e73628a423715a09eaf4b492ffae7bdbcdabdf65cde48ea5d6f9d5`.
