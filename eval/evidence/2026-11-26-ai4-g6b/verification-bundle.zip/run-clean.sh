#!/usr/bin/env bash
set -euo pipefail
base=$1
src=$2
logs=$3
mkdir -p "$logs"/{backend,frontend,browser}
evidence=eval/evidence/2026-11-26-ai4-g6b
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 LANG=C.UTF-8 TZ=UTC
export OPENAI_API_KEY= LANGSMITH_TRACING=false DATABASE_URL="sqlite:///$logs/offline.db"
export NEXT_TELEMETRY_DISABLED=1 PLAYWRIGHT_BROWSERS_PATH="$base/browser"
export LD_LIBRARY_PATH="$base/libs/usr/lib/x86_64-linux-gnu"
export NO_PROXY=127.0.0.1,localhost no_proxy=127.0.0.1,localhost
unset TEST_DATABASE_URL
cd "$src"
run() {
  local folder=$1 name=$2 rc=0
  shift 2
  "$@" > "$logs/$folder/$name.log" 2>&1 || rc=$?
  printf '%s\t%s\n' "$name" "$rc" >> "$logs/$folder/exits.tsv"
  return "$rc"
}
backend() (
  local rc=0
  printf 'check\texit\n' > "$logs/backend/exits.tsv"
  run backend new-regressions timeout -k 3s 75s pytest -q --junitxml="$logs/backend/new-regressions.xml" tests/test_api/test_g6b_v3_bounds_and_disconnect.py || rc=1
  bash "$evidence/verify.sh" "$logs/backend" || rc=1
  return "$rc"
)
frontend() (
  local rc=0
  cd frontend
  export NEXT_PUBLIC_API_URL=http://127.0.0.1:38190
  printf 'check\texit\n' > "$logs/frontend/exits.tsv"
  run frontend test timeout -k 3s 90s npm test || rc=1
  run frontend lint timeout -k 3s 90s npm run lint || rc=1
  run frontend typecheck timeout -k 3s 90s npm run typecheck || rc=1
  cp src/lib/api/schema.d.ts "$logs/frontend/schema.expected"
  run frontend gen-api timeout -k 3s 90s npm run gen:api || rc=1
  run frontend schema cmp "$logs/frontend/schema.expected" src/lib/api/schema.d.ts || rc=1
  run frontend turbopack timeout -k 3s 150s npm run build || rc=1
  run frontend webpack timeout -k 3s 150s npm run build -- --webpack || return 1
  return "$rc"
)
wait_http() {
  local url=$1
  for attempt in $(seq 1 60)
  do
    if curl --fail --silent --max-time 1 "$url" > /dev/null
    then
      return 0
    fi
    sleep 1
  done
  return 1
}
browser() (
  local api_pid= fe_pid= rc=0
  cleanup() {
    if [[ -n $api_pid ]]; then kill "$api_pid" 2>/dev/null || true; fi
    if [[ -n $fe_pid ]]; then kill "$fe_pid" 2>/dev/null || true; fi
  }
  trap cleanup EXIT
  printf 'check\texit\n' > "$logs/browser/exits.tsv"
  for scope in two-roles ranked
  do
    local demo_args=() browser_args=()
    if [[ $scope == ranked ]]; then demo_args+=(--ranked); browser_args+=(--ranked); fi
    CORS_ORIGINS=http://127.0.0.1:33190 python "$evidence/run_demo.py" --port 38190 "${demo_args[@]}" > "$logs/browser/$scope-api.log" 2>&1 &
    api_pid=$!
    if [[ -z $fe_pid ]]; then
      (cd frontend && exec node node_modules/next/dist/bin/next start --hostname 127.0.0.1 --port 33190) > "$logs/browser/frontend.log" 2>&1 &
      fe_pid=$!
    fi
    wait_http http://127.0.0.1:38190/openapi.json && wait_http http://127.0.0.1:33190/login || return 1
    run browser "$scope" timeout -k 3s 130s node "$evidence/browser_smoke.mjs" "$base/toolkit" http://127.0.0.1:33190 "${browser_args[@]}" || rc=1
    kill "$api_pid" 2>/dev/null || true
    wait "$api_pid" 2>/dev/null || true
    api_pid=
  done
  return "$rc"
)
backend &
backend_pid=$!
result=0
frontend || result=1
if rg -q '^webpack\s+0$' "$logs/frontend/exits.tsv"; then browser || result=1; fi
wait "$backend_pid" || result=1
exit "$result"
